import type { Product } from "./data";

export type CartItem = Product & { qty: number };

type Props = {
  items: CartItem[];
  onClose: () => void;
  onInc: (id: number) => void;
  onDec: (id: number) => void;
  onRemove: (id: number) => void;
};

export function Cart({ items, onClose, onInc, onDec, onRemove }: Props) {
  const total = items.reduce((s, i) => s + i.price * i.qty, 0);
  return (
    <>
      <div className="shop-overlay" onClick={onClose} />
      <aside className="shop-cart">
        <div className="shop-cart-header">
          <h3>Your Bag ({items.length})</h3>
          <button className="shop-cart-close" onClick={onClose} aria-label="Close">×</button>
        </div>
        <div className="shop-cart-body">
          {items.length === 0 ? (
            <div className="shop-cart-empty">
              <div style={{ fontSize: 48, marginBottom: 12 }}>🛍️</div>
              Your bag is empty.
            </div>
          ) : (
            items.map((item) => (
              <div key={item.id} className="shop-cart-item">
                <div className="shop-cart-item-img" style={{ background: item.bg }}>{item.emoji}</div>
                <div className="shop-cart-item-info">
                  <div className="shop-cart-item-name">{item.name}</div>
                  <div className="shop-cart-item-price">${item.price}</div>
                  <div className="shop-qty">
                    <button onClick={() => onDec(item.id)}>−</button>
                    <span>{item.qty}</span>
                    <button onClick={() => onInc(item.id)}>+</button>
                  </div>
                </div>
                <button className="shop-cart-remove" onClick={() => onRemove(item.id)} aria-label="Remove">×</button>
              </div>
            ))
          )}
        </div>
        {items.length > 0 && (
          <div className="shop-cart-footer">
            <div className="shop-cart-total">
              <span>Subtotal</span>
              <span>${total}</span>
            </div>
            <button className="shop-checkout-btn">Checkout →</button>
          </div>
        )}
      </aside>
    </>
  );
}
