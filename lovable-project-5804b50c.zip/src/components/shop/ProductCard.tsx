import type { Product } from "./data";

type Props = {
  product: Product;
  onAdd: (p: Product) => void;
};

export function ProductCard({ product, onAdd }: Props) {
  return (
    <article className="shop-card">
      <div className="shop-card-image" style={{ background: product.bg }}>
        {product.badge && <span className="shop-card-badge">{product.badge}</span>}
        <button className="shop-card-fav" aria-label="Favorite">♡</button>
        <span>{product.emoji}</span>
      </div>
      <div className="shop-card-body">
        <div className="shop-card-cat">{product.category}</div>
        <div className="shop-card-name">{product.name}</div>
        <div className="shop-card-bottom">
          <div className="shop-card-price">${product.price}</div>
          <button className="shop-card-add" onClick={() => onAdd(product)} aria-label="Add to cart">+</button>
        </div>
      </div>
    </article>
  );
}
