import { useState, useMemo, useRef } from "react";
import "./shop.css";
import { Header } from "./Header";
import { Hero } from "./Hero";
import { ProductCard } from "./ProductCard";
import { Cart, type CartItem } from "./Cart";
import { Footer } from "./Footer";
import { PRODUCTS, CATEGORIES, type Product } from "./data";

export function Shop() {
  const [category, setCategory] = useState("All");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const gridRef = useRef<HTMLDivElement>(null);

  const filtered = useMemo(
    () => (category === "All" ? PRODUCTS : PRODUCTS.filter((p) => p.category === category)),
    [category]
  );

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  const addToCart = (p: Product) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === p.id);
      if (existing) return prev.map((i) => (i.id === p.id ? { ...i, qty: i.qty + 1 } : i));
      return [...prev, { ...p, qty: 1 }];
    });
    setCartOpen(true);
  };

  const inc = (id: number) => setCart((p) => p.map((i) => (i.id === id ? { ...i, qty: i.qty + 1 } : i)));
  const dec = (id: number) =>
    setCart((p) => p.flatMap((i) => (i.id === id ? (i.qty > 1 ? [{ ...i, qty: i.qty - 1 }] : []) : [i])));
  const remove = (id: number) => setCart((p) => p.filter((i) => i.id !== id));

  const scrollToShop = () => gridRef.current?.scrollIntoView({ behavior: "smooth" });

  return (
    <div className="shop-app">
      <Header cartCount={cartCount} onCartOpen={() => setCartOpen(true)} />
      <Hero onShop={scrollToShop} />

      <section className="shop-section" ref={gridRef}>
        <div className="shop-section-head">
          <div>
            <h2>The Collection</h2>
            <p>Crafted essentials for the considered wardrobe.</p>
          </div>
          <div className="shop-filters">
            {CATEGORIES.map((c) => (
              <button
                key={c}
                className={`shop-filter-btn ${category === c ? "active" : ""}`}
                onClick={() => setCategory(c)}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        <div className="shop-grid">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} onAdd={addToCart} />
          ))}
        </div>
      </section>

      <Footer />

      {cartOpen && (
        <Cart items={cart} onClose={() => setCartOpen(false)} onInc={inc} onDec={dec} onRemove={remove} />
      )}
    </div>
  );
}
