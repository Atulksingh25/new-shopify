export type Product = {
  id: number;
  name: string;
  category: string;
  price: number;
  emoji: string;
  bg: string;
  badge?: string;
};

export const PRODUCTS: Product[] = [
  { id: 1, name: "Classic Leather Tote", category: "Bags", price: 189, emoji: "👜", bg: "#f4ddc8", badge: "New" },
  { id: 2, name: "Wool Blend Overcoat", category: "Outerwear", price: 349, emoji: "🧥", bg: "#d4c5b0" },
  { id: 3, name: "Suede Ankle Boots", category: "Shoes", price: 229, emoji: "👢", bg: "#e8b89a", badge: "Hot" },
  { id: 4, name: "Linen Button Shirt", category: "Tops", price: 89, emoji: "👔", bg: "#e0e8d8" },
  { id: 5, name: "Cashmere Knit Sweater", category: "Tops", price: 159, emoji: "🧶", bg: "#f0d8d0" },
  { id: 6, name: "Tailored Wide Trousers", category: "Bottoms", price: 119, emoji: "👖", bg: "#c8d0e0" },
  { id: 7, name: "Minimal Gold Watch", category: "Accessories", price: 279, emoji: "⌚", bg: "#f0e0c0", badge: "Sale" },
  { id: 8, name: "Silk Scarf Print", category: "Accessories", price: 79, emoji: "🧣", bg: "#e8c8d8" },
];

export const CATEGORIES = ["All", "Bags", "Outerwear", "Shoes", "Tops", "Bottoms", "Accessories"];
