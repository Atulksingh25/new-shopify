export function Footer() {
  return (
    <footer className="shop-footer">
      <div className="shop-footer-inner">
        <div>
          <div className="shop-footer-brand">ATELIER<span>.</span></div>
          <p style={{ fontSize: 14, lineHeight: 1.6, margin: 0 }}>
            Quiet luxury essentials, designed in studio and crafted to last.
          </p>
        </div>
        <div>
          <h4>Shop</h4>
          <ul>
            <li>New Arrivals</li>
            <li>Bestsellers</li>
            <li>Collections</li>
            <li>Sale</li>
          </ul>
        </div>
        <div>
          <h4>Help</h4>
          <ul>
            <li>Shipping</li>
            <li>Returns</li>
            <li>Size Guide</li>
            <li>Contact</li>
          </ul>
        </div>
        <div>
          <h4>Company</h4>
          <ul>
            <li>About</li>
            <li>Journal</li>
            <li>Sustainability</li>
            <li>Careers</li>
          </ul>
        </div>
      </div>
      <div className="shop-footer-copy">© 2026 Atelier Studio. All rights reserved.</div>
    </footer>
  );
}
