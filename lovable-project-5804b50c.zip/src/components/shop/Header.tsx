type Props = {
  cartCount: number;
  onCartOpen: () => void;
};

export function Header({ cartCount, onCartOpen }: Props) {
  return (
    <header className="shop-header">
      <div className="shop-header-inner">
        <div className="shop-logo">ATELIER<span>.</span></div>
        <nav className="shop-nav">
          <button className="active">Shop</button>
          <button>New Arrivals</button>
          <button>Collections</button>
          <button>Journal</button>
          <button>About</button>
        </nav>
        <div className="shop-header-actions">
          <button className="shop-icon-btn" aria-label="Search">🔍</button>
          <button className="shop-icon-btn" aria-label="Account">👤</button>
          <button className="shop-icon-btn" aria-label="Cart" onClick={onCartOpen}>
            🛍️
            {cartCount > 0 && <span className="shop-cart-badge">{cartCount}</span>}
          </button>
        </div>
      </div>
    </header>
  );
}
