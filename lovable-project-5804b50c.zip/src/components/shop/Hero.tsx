type Props = { onShop: () => void };

export function Hero({ onShop }: Props) {
  return (
    <section className="shop-hero">
      <div>
        <h1>
          Quiet luxury,<br />
          everyday <em>essentials</em>.
        </h1>
        <p>
          Thoughtfully designed pieces crafted from premium materials.
          Built to last, made to be loved season after season.
        </p>
        <button className="shop-hero-cta" onClick={onShop}>
          Shop the collection →
        </button>
      </div>
      <div className="shop-hero-visual">👜</div>
    </section>
  );
}
