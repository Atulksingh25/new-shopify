import Product from "./Product";

// List component - products ko map karke dikhata hai
export default function ProductList({ products, onAdd }: any) {
  return (
    <div className="shop-list">
      {products.map(function (p: any) {
        return (
          <Product
            key={p.id}        // unique key required
            product={p}       // product data
            onAdd={onAdd}     // parent ka function
          />
        );
      })}
    </div>
  );
}
