// Cart summary - sirf count aur total dikhata hai
// Conditional rendering ka example
export default function Cart({ count, total }: any) {
  if (count === 0) {
    return <div className="shop-empty">Cart khali hai 🛒</div>;
  }

  return (
    <div className="shop-cart-info">
      🛍️ Items: {count} | Total: ₹{total}
    </div>
  );
}
