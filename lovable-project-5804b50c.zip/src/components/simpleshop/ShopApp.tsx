import { useState } from "react";
import "./shop.css";
import ProductList from "./ProductList";
import Cart from "./Cart";

// Parent component - sara state yaha
export default function ShopApp() {
  // Saare products ki list (static data)
  const products = [
    { id: 1, name: "Apple", price: 50, emoji: "🍎" },
    { id: 2, name: "Banana", price: 20, emoji: "🍌" },
    { id: 3, name: "Burger", price: 100, emoji: "🍔" },
    { id: 4, name: "Pizza", price: 200, emoji: "🍕" },
  ];

  // Cart state - jo items add huye
  const [cart, setCart] = useState<any[]>([]);

  // Product ko cart me add karna
  function addToCart(product: any) {
    setCart([...cart, product]); // purana cart + naya item
  }

  // Total price calculate karna
  const total = cart.reduce(function (sum, item) {
    return sum + item.price;
  }, 0);

  return (
    <div className="shop-app">
      <h1 className="shop-title">🛒 Simple Shop</h1>

      {/* Cart summary */}
      <Cart count={cart.length} total={total} />

      {/* Product list - data + function as props */}
      <ProductList products={products} onAdd={addToCart} />
    </div>
  );
}
