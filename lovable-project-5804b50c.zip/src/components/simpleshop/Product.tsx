// Single product card - dumb component
// Sirf props leta hai, dikhata hai, button click pe parent ko bolta hai
export default function Product({ product, onAdd }: any) {
  return (
    <div className="shop-item">
      <div className="shop-item-emoji">{product.emoji}</div>
      <div className="shop-item-name">{product.name}</div>
      <div className="shop-item-price">₹{product.price}</div>

      {/* Button click pe parent ka function call */}
      <button className="shop-btn" onClick={function () { onAdd(product); }}>
        Add to Cart
      </button>
    </div>
  );
}
