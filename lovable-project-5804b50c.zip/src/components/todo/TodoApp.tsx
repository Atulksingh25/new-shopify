import { useState } from "react";
import "./todo.css";
import TodoInput from "./TodoInput";
import TodoList from "./TodoList";

// Main component - yaha sara state rehta hai (parent)
export default function TodoApp() {
  // useState hook - todos ki list store karne ke liye
  const [todos, setTodos] = useState<any[]>([]);

  // Naya todo add karne ka function
  function addTodo(text: string) {
    const newTodo = {
      id: Date.now(),   // unique id
      text: text,       // user ne jo likha
      done: false,      // initially incomplete
    };
    setTodos([...todos, newTodo]);  // purani list + naya todo
  }

  // Todo ko complete/incomplete toggle karna
  function toggleTodo(id: number) {
    const updated = todos.map(function (t) {
      if (t.id === id) {
        return { ...t, done: !t.done };
      }
      return t;
    });
    setTodos(updated);
  }

  // Todo delete karna
  function deleteTodo(id: number) {
    const filtered = todos.filter(function (t) {
      return t.id !== id;
    });
    setTodos(filtered);
  }

  return (
    <div className="todo-app">
      <h1 className="todo-title">My Todo List</h1>

      {/* Child component ko function as prop bhej rahe hain */}
      <TodoInput onAdd={addTodo} />

      {/* List ko data aur functions props me bhejte hain */}
      <TodoList
        todos={todos}
        onToggle={toggleTodo}
        onDelete={deleteTodo}
      />

      <p className="todo-count">Total: {todos.length}</p>
    </div>
  );
}
