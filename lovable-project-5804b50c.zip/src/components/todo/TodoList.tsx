import TodoItem from "./TodoItem";

// List component - sirf todos ko loop karke dikhata hai
// Props: todos (array), onToggle, onDelete
export default function TodoList({ todos, onToggle, onDelete }: any) {
  // Agar koi todo nahi hai
  if (todos.length === 0) {
    return <p className="todo-empty">Koi task nahi hai. Naya add karo!</p>;
  }

  return (
    <ul className="todo-list">
      {/* map se loop - har todo ke liye ek TodoItem */}
      {todos.map(function (todo: any) {
        return (
          <TodoItem
            key={todo.id}       // React ke liye unique key
            todo={todo}
            onToggle={onToggle}
            onDelete={onDelete}
          />
        );
      })}
    </ul>
  );
}
