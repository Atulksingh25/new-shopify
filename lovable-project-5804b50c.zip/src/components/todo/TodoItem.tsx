// Single todo row - sabse chhota component
// Props: todo (object), onToggle, onDelete
export default function TodoItem({ todo, onToggle, onDelete }: any) {
  return (
    <li className={"todo-item " + (todo.done ? "done" : "")}>
      {/* Checkbox - click par toggle */}
      <input
        type="checkbox"
        checked={todo.done}
        onChange={function () { onToggle(todo.id); }}
      />

      {/* Todo ka text */}
      <span className="todo-text">{todo.text}</span>

      {/* Delete button */}
      <button
        className="todo-delete"
        onClick={function () { onDelete(todo.id); }}
      >
        X
      </button>
    </li>
  );
}
