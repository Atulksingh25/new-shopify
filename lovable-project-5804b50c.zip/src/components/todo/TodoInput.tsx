import { useState } from "react";

// Child component - input field
// Props: onAdd (function) - parent ne diya hai
export default function TodoInput({ onAdd }: any) {
  // Local state - input box ki value
  const [text, setText] = useState("");

  // Form submit hone par
  function handleSubmit(e: any) {
    e.preventDefault();           // page reload rokna
    if (text.trim() === "") return; // khali input ignore
    onAdd(text);                  // parent ka function call
    setText("");                  // input clear
  }

  return (
    <form className="todo-form" onSubmit={handleSubmit}>
      <input
        type="text"
        className="todo-input"
        placeholder="Naya task likho..."
        value={text}
        onChange={function (e: any) { setText(e.target.value); }}
      />
      <button type="submit" className="todo-btn">Add</button>
    </form>
  );
}
