// Single product - dumb component
// Sirf props leta hai aur click pe parent ko bolta hai
export default function Product({ product, onAdd }: any) {
  return (
    <li className="product">
      <span>
        {product.name} - ₹{product.price}
      </span>
      <button onClick={function () { onAdd(product); }}>Add</button>
    </li>
  );
}
