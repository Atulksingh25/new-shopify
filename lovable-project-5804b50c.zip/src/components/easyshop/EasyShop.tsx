import { useState } from "react";
import "./easyshop.css";
import ProductList from "./ProductList";
import Cart from "./Cart";

// Parent component - sara state yaha hai
export default function EasyShop() {
  // Products ki list (static data)
  const products = [
    { id: 1, name: "Apple", price: 50 },
    { id: 2, name: "Banana", price: 20 },
    { id: 3, name: "Mango", price: 80 },
  ];

  // Cart state
  const [cart, setCart] = useState<any[]>([]);

  // Cart me item add karna
  function addToCart(item: any) {
    setCart([...cart, item]);
  }

  // Total price nikalna
  let total = 0;
  for (let i = 0; i < cart.length; i++) {
    total = total + cart[i].price;
  }

  return (
    <div className="easy-shop">
      <h1>🛒 Easy Shop</h1>

      {/* Cart component ko data props me bhejo */}
      <Cart count={cart.length} total={total} />

      {/* ProductList ko data + function props me bhejo */}
      <ProductList products={products} onAdd={addToCart} />
    </div>
  );
}
