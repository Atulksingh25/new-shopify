// Cart component - sirf count aur total dikhata hai
export default function Cart({ count, total }: any) {
  return (
    <p className="cart-info">
      Items: {count} | Total: ₹{total}
    </p>
  );
}
