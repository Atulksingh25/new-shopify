import Product from "./Product";

// List component - products ko map karke dikhata hai
export default function ProductList({ products, onAdd }: any) {
  return (
    <ul className="product-list">
      {products.map(function (p: any) {
        return <Product key={p.id} product={p} onAdd={onAdd} />;
      })}
    </ul>
  );
}
