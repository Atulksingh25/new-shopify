// Header - logo, search bar, cart icon
export default function Header({ cartCount, search, onSearch, onCartClick }: any) {
  return (
    <header className="az-header">
      <div className="az-logo">amazon<span>.in</span></div>

      <div className="az-search">
        <input
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={function (e) { onSearch(e.target.value); }}
        />
        <button>🔍</button>
      </div>

      <div className="az-nav">
        <div className="az-nav-item">
          <small>Hello, Sign in</small>
          <strong>Account & Lists</strong>
        </div>
        <div className="az-nav-item">
          <small>Returns</small>
          <strong>& Orders</strong>
        </div>
        <button className="az-cart-btn" onClick={onCartClick}>
          🛒 <span className="az-cart-count">{cartCount}</span>
          <strong>Cart</strong>
        </button>
      </div>
    </header>
  );
}
