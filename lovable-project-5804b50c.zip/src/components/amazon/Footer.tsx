// Simple footer
export default function Footer() {
  return (
    <footer className="az-footer">
      <div className="az-footer-grid">
        <div>
          <h4>Get to Know Us</h4>
          <p>About</p>
          <p>Careers</p>
          <p>Press</p>
        </div>
        <div>
          <h4>Connect</h4>
          <p>Facebook</p>
          <p>Twitter</p>
          <p>Instagram</p>
        </div>
        <div>
          <h4>Make Money</h4>
          <p>Sell on Amazon</p>
          <p>Affiliate</p>
        </div>
        <div>
          <h4>Help</h4>
          <p>Your Account</p>
          <p>Returns</p>
        </div>
      </div>
      <div className="az-footer-bottom">© 2026 Amazon Clone - React Project</div>
    </footer>
  );
}
