// Single product card - emoji, name, rating, price, add button
export default function ProductCard({ product, onAdd }: any) {
  return (
    <div className="az-card">
      <div className="az-card-img">{product.emoji}</div>
      <div className="az-card-name">{product.name}</div>
      <div className="az-card-rating">
        ⭐ {product.rating} <small>({product.category})</small>
      </div>
      <div className="az-card-price">₹{product.price.toLocaleString()}</div>
      <button className="az-card-btn" onClick={function () { onAdd(product); }}>
        Add to Cart
      </button>
    </div>
  );
}
