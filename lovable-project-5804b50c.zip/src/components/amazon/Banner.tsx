// Hero banner - static
export default function Banner() {
  return (
    <div className="az-banner">
      <div className="az-banner-text">
        <h2>Big Billion Sale 🎉</h2>
        <p>Up to 70% off on top brands. Limited time offer!</p>
        <button>Shop Now</button>
      </div>
      <div className="az-banner-emoji">🛍️</div>
    </div>
  );
}
