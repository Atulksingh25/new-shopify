// Cart drawer - items list + qty + remove + total
export default function Cart({ items, onClose, onInc, onDec, onRemove }: any) {
  // Total price
  let total = 0;
  for (let i = 0; i < items.length; i++) {
    total = total + items[i].price * items[i].qty;
  }

  return (
    <div className="az-cart-overlay" onClick={onClose}>
      <div className="az-cart" onClick={function (e) { e.stopPropagation(); }}>
        <div className="az-cart-head">
          <h3>Your Cart ({items.length})</h3>
          <button onClick={onClose}>✕</button>
        </div>

        <div className="az-cart-body">
          {items.length === 0 && (
            <div className="az-cart-empty">Cart khali hai 🛒</div>
          )}

          {items.map(function (item: any) {
            return (
              <div key={item.id} className="az-cart-item">
                <div className="az-cart-emoji">{item.emoji}</div>
                <div className="az-cart-info">
                  <div className="az-cart-name">{item.name}</div>
                  <div className="az-cart-price">₹{item.price.toLocaleString()}</div>
                  <div className="az-qty">
                    <button onClick={function () { onDec(item.id); }}>-</button>
                    <span>{item.qty}</span>
                    <button onClick={function () { onInc(item.id); }}>+</button>
                  </div>
                </div>
                <button className="az-remove" onClick={function () { onRemove(item.id); }}>
                  🗑️
                </button>
              </div>
            );
          })}
        </div>

        {items.length > 0 && (
          <div className="az-cart-foot">
            <div className="az-cart-total">
              <span>Total:</span>
              <strong>₹{total.toLocaleString()}</strong>
            </div>
            <button className="az-checkout">Proceed to Buy</button>
          </div>
        )}
      </div>
    </div>
  );
}
