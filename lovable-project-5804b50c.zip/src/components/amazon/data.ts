// Saare products ka data (static)
export const products = [
  { id: 1, name: "iPhone 15 Pro", price: 134999, rating: 4.5, emoji: "📱", category: "Electronics" },
  { id: 2, name: "MacBook Air M2", price: 114999, rating: 4.7, emoji: "💻", category: "Electronics" },
  { id: 3, name: "Sony Headphones", price: 24999, rating: 4.6, emoji: "🎧", category: "Electronics" },
  { id: 4, name: "Smart Watch", price: 8999, rating: 4.2, emoji: "⌚", category: "Electronics" },

  { id: 5, name: "Nike Shoes", price: 4999, rating: 4.3, emoji: "👟", category: "Fashion" },
  { id: 6, name: "Leather Jacket", price: 3499, rating: 4.1, emoji: "🧥", category: "Fashion" },
  { id: 7, name: "Sunglasses", price: 1299, rating: 4.0, emoji: "🕶️", category: "Fashion" },
  { id: 8, name: "Handbag", price: 2499, rating: 4.4, emoji: "👜", category: "Fashion" },

  { id: 9, name: "React Book", price: 599, rating: 4.8, emoji: "📕", category: "Books" },
  { id: 10, name: "JS Guide", price: 499, rating: 4.6, emoji: "📘", category: "Books" },
  { id: 11, name: "DSA Book", price: 799, rating: 4.7, emoji: "📗", category: "Books" },
  { id: 12, name: "Novel Set", price: 999, rating: 4.5, emoji: "📚", category: "Books" },

  { id: 13, name: "Coffee Maker", price: 5999, rating: 4.3, emoji: "☕", category: "Home" },
  { id: 14, name: "Table Lamp", price: 1499, rating: 4.2, emoji: "💡", category: "Home" },
  { id: 15, name: "Cushion Set", price: 899, rating: 4.0, emoji: "🛋️", category: "Home" },
  { id: 16, name: "Wall Clock", price: 1199, rating: 4.1, emoji: "🕐", category: "Home" },
];

// Categories
export const categories = ["All", "Electronics", "Fashion", "Books", "Home"];
