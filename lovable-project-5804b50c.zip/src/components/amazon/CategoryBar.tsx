// Category filter buttons
export default function CategoryBar({ categories, selected, onSelect }: any) {
  return (
    <nav className="az-catbar">
      {categories.map(function (c: string) {
        return (
          <button
            key={c}
            className={"az-cat-btn " + (selected === c ? "active" : "")}
            onClick={function () { onSelect(c); }}
          >
            {c}
          </button>
        );
      })}
    </nav>
  );
}
