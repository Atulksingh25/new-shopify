import ProductCard from "./ProductCard";

// Products ki grid
export default function ProductList({ products, onAdd }: any) {
  if (products.length === 0) {
    return <div className="az-empty">No products found 😔</div>;
  }

  return (
    <div className="az-grid">
      {products.map(function (p: any) {
        return <ProductCard key={p.id} product={p} onAdd={onAdd} />;
      })}
    </div>
  );
}
