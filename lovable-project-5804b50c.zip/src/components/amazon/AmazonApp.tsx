import { useState } from "react";
import "./amazon.css";
import Header from "./Header";
import CategoryBar from "./CategoryBar";
import Banner from "./Banner";
import ProductList from "./ProductList";
import Cart from "./Cart";
import Footer from "./Footer";
import { products, categories } from "./data";

// Parent component - sara state yaha
export default function AmazonApp() {
  // 3 states: cart items, search text, selected category
  const [cart, setCart] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [cartOpen, setCartOpen] = useState(false);

  // Add to cart - agar already hai to qty badhao, nahi to naya add
  function addToCart(p: any) {
    const found = cart.find(function (i) { return i.id === p.id; });
    if (found) {
      setCart(cart.map(function (i) {
        if (i.id === p.id) return { ...i, qty: i.qty + 1 };
        return i;
      }));
    } else {
      setCart([...cart, { ...p, qty: 1 }]);
    }
  }

  // Quantity increase
  function incQty(id: number) {
    setCart(cart.map(function (i) {
      if (i.id === id) return { ...i, qty: i.qty + 1 };
      return i;
    }));
  }

  // Quantity decrease
  function decQty(id: number) {
    setCart(cart.map(function (i) {
      if (i.id === id) return { ...i, qty: i.qty - 1 };
      return i;
    }).filter(function (i) { return i.qty > 0; }));
  }

  // Remove from cart
  function removeItem(id: number) {
    setCart(cart.filter(function (i) { return i.id !== id; }));
  }

  // Filter products by category + search
  let visible = products;
  if (category !== "All") {
    visible = visible.filter(function (p) { return p.category === category; });
  }
  if (search !== "") {
    visible = visible.filter(function (p) {
      return p.name.toLowerCase().includes(search.toLowerCase());
    });
  }

  // Total items in cart
  let totalItems = 0;
  for (let i = 0; i < cart.length; i++) {
    totalItems = totalItems + cart[i].qty;
  }

  return (
    <div className="amazon-app">
      <Header
        cartCount={totalItems}
        search={search}
        onSearch={setSearch}
        onCartClick={function () { setCartOpen(true); }}
      />

      <CategoryBar
        categories={categories}
        selected={category}
        onSelect={setCategory}
      />

      <Banner />

      <ProductList products={visible} onAdd={addToCart} />

      <Footer />

      {cartOpen && (
        <Cart
          items={cart}
          onClose={function () { setCartOpen(false); }}
          onInc={incQty}
          onDec={decQty}
          onRemove={removeItem}
        />
      )}
    </div>
  );
}
