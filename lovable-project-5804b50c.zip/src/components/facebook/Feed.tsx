import { useEffect, useState } from "react";
import { Stories } from "./Stories";
import { CreatePost } from "./CreatePost";
import { Post, type PostData } from "./Post";

const seed: PostData[] = [
  {
    id: "1",
    author: "Maria Garcia",
    initials: "MG",
    color: "#48bb78",
    time: "2h",
    text: "Sunset hike today was unreal 🌄 Nature really is the best therapy.",
    image:
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=900&q=80",
    likes: 124,
    comments: 18,
    shares: 4,
  },
  {
    id: "2",
    author: "Alex Johnson",
    initials: "AJ",
    color: "#f56565",
    time: "5h",
    text: "Just shipped a new side project after 3 weekends of grinding. Ask me anything 👇",
    likes: 56,
    comments: 12,
    shares: 1,
  },
  {
    id: "3",
    author: "Priya Patel",
    initials: "PP",
    color: "#9f7aea",
    time: "1d",
    text: "Coffee, code, repeat ☕️",
    image:
      "https://images.unsplash.com/photo-1521017432531-fbd92d768814?w=900&q=80",
    likes: 312,
    comments: 47,
    shares: 9,
  },
];

export function Feed() {
  const [posts, setPosts] = useState<PostData[]>([]);

  useEffect(() => {
    setPosts(seed);
  }, []);

  const addPost = (text: string) => {
    const newPost: PostData = {
      id: crypto.randomUUID(),
      author: "Jane Doe",
      initials: "JD",
      color: "#1877f2",
      time: "Just now",
      text,
      likes: 0,
      comments: 0,
      shares: 0,
    };
    setPosts((p) => [newPost, ...p]);
  };

  return (
    <div className="fb-feed">
      <Stories />
      <CreatePost onCreate={addPost} />
      {posts.map((p) => (
        <Post key={p.id} post={p} />
      ))}
    </div>
  );
}
