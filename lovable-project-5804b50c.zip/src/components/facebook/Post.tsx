import { useState } from "react";

export interface PostData {
  id: string;
  author: string;
  initials: string;
  color: string;
  time: string;
  text: string;
  image?: string;
  likes: number;
  comments: number;
  shares: number;
}

export function Post({ post }: { post: PostData }) {
  const [liked, setLiked] = useState(false);
  const likeCount = post.likes + (liked ? 1 : 0);

  return (
    <article className="fb-card">
      <header className="fb-post-header">
        <div className="fb-post-avatar" style={{ background: post.color }}>
          {post.initials}
        </div>
        <div>
          <div className="fb-post-name">{post.author}</div>
          <div className="fb-post-time">{post.time} · 🌐</div>
        </div>
      </header>
      {post.text && <p className="fb-post-text">{post.text}</p>}
      {post.image && <img className="fb-post-image" src={post.image} alt="" />}
      <div className="fb-post-stats">
        <div className="fb-likes-pill">
          <span className="fb-likes-emoji">👍</span>
          <span>{likeCount}</span>
        </div>
        <div>{post.comments} comments · {post.shares} shares</div>
      </div>
      <div className="fb-post-actions">
        <button
          className={`fb-post-action ${liked ? "liked" : ""}`}
          onClick={() => setLiked((v) => !v)}
        >
          👍 Like
        </button>
        <button className="fb-post-action">💬 Comment</button>
        <button className="fb-post-action">↗ Share</button>
      </div>
    </article>
  );
}
