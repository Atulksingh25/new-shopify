const contacts = [
  { name: "Alex Johnson", color: "#f56565" },
  { name: "Maria Garcia", color: "#48bb78" },
  { name: "Sam O'Neil", color: "#ed8936" },
  { name: "Priya Patel", color: "#9f7aea" },
  { name: "Liam Chen", color: "#38b2ac" },
  { name: "Noah Williams", color: "#ecc94b" },
  { name: "Emma Brown", color: "#ed64a6" },
  { name: "Olivia Davis", color: "#4299e1" },
];

function initials(n: string) {
  return n.split(" ").map((s) => s[0]).join("").slice(0, 2).toUpperCase();
}

export function Contacts() {
  return (
    <aside className="fb-sidebar-right">
      <div className="fb-sidebar-title">Contacts</div>
      {contacts.map((c) => (
        <div key={c.name} className="fb-contact">
          <div className="fb-post-avatar" style={{ background: c.color }}>
            {initials(c.name)}
          </div>
          <span style={{ fontWeight: 500 }}>{c.name}</span>
          <div className="fb-contact-dot" />
        </div>
      ))}
    </aside>
  );
}
