import { useEffect, useRef, useState } from "react";

interface Props {
  onCreate: (text: string) => void;
}

export function CreatePost({ onCreate }: Props) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const ref = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (open) ref.current?.focus();
  }, [open]);

  const submit = () => {
    if (!text.trim()) return;
    onCreate(text.trim());
    setText("");
    setOpen(false);
  };

  return (
    <>
      <div className="fb-card">
        <div className="fb-create-row">
          <div className="fb-avatar">JD</div>
          <button className="fb-create-input" onClick={() => setOpen(true)}>
            What's on your mind, Jane?
          </button>
        </div>
        <div className="fb-create-actions">
          <button className="fb-create-action" onClick={() => setOpen(true)}>
            <span style={{ color: "#f3425f" }}>🎥</span> Live video
          </button>
          <button className="fb-create-action" onClick={() => setOpen(true)}>
            <span style={{ color: "#45bd62" }}>🖼️</span> Photo/video
          </button>
          <button className="fb-create-action" onClick={() => setOpen(true)}>
            <span style={{ color: "#f7b928" }}>😊</span> Feeling
          </button>
        </div>
      </div>

      {open && (
        <div className="fb-modal-backdrop" onClick={() => setOpen(false)}>
          <div className="fb-modal" onClick={(e) => e.stopPropagation()}>
            <div className="fb-modal-header">
              Create post
              <button className="fb-modal-close" onClick={() => setOpen(false)}>✕</button>
            </div>
            <div className="fb-modal-body">
              <div className="fb-modal-row">
                <div className="fb-avatar">JD</div>
                <div>
                  <div style={{ fontWeight: 600 }}>Jane Doe</div>
                  <div style={{ fontSize: 12, color: "#65676b" }}>🌐 Public</div>
                </div>
              </div>
              <textarea
                ref={ref}
                className="fb-modal-textarea"
                placeholder="What's on your mind, Jane?"
                value={text}
                onChange={(e) => setText(e.target.value)}
              />
              <button
                className="fb-modal-submit"
                disabled={!text.trim()}
                onClick={submit}
              >
                Post
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
