const items = [
  { icon: "👤", label: "Jane Doe" },
  { icon: "👥", label: "Friends" },
  { icon: "📺", label: "Watch" },
  { icon: "🛒", label: "Marketplace" },
  { icon: "👨‍👩‍👧", label: "Groups" },
  { icon: "🎮", label: "Gaming" },
  { icon: "📅", label: "Events" },
  { icon: "🕒", label: "Memories" },
  { icon: "🔖", label: "Saved" },
  { icon: "🚩", label: "Pages" },
];

export function Sidebar() {
  return (
    <aside className="fb-sidebar-left">
      {items.map((i) => (
        <div key={i.label} className="fb-sidebar-item">
          <div className="fb-sidebar-icon">{i.icon}</div>
          <span>{i.label}</span>
        </div>
      ))}
    </aside>
  );
}
