const stories = [
  { name: "Your story", initials: "JD", bg: "linear-gradient(135deg,#1877f2,#42a5f5)" },
  { name: "Alex Johnson", initials: "AJ", bg: "linear-gradient(135deg,#f56565,#fc8181)" },
  { name: "Maria Garcia", initials: "MG", bg: "linear-gradient(135deg,#48bb78,#68d391)" },
  { name: "Priya Patel", initials: "PP", bg: "linear-gradient(135deg,#9f7aea,#b794f4)" },
];

export function Stories() {
  return (
    <div className="fb-stories">
      {stories.map((s) => (
        <div key={s.name} className="fb-story" style={{ background: s.bg }}>
          <div className="fb-story-avatar">{s.initials}</div>
          <div className="fb-story-name">{s.name}</div>
        </div>
      ))}
    </div>
  );
}
