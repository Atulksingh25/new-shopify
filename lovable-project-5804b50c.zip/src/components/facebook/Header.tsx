import { useState } from "react";

const navItems = [
  { id: "home", icon: "🏠" },
  { id: "friends", icon: "👥" },
  { id: "watch", icon: "📺" },
  { id: "groups", icon: "👨‍👩‍👧" },
  { id: "games", icon: "🎮" },
];

export function Header() {
  const [active, setActive] = useState("home");
  return (
    <header className="fb-header">
      <div className="fb-header-left">
        <div className="fb-logo">f</div>
        <input className="fb-search" placeholder="Search Facebook" />
      </div>
      <nav className="fb-header-center">
        {navItems.map((n) => (
          <button
            key={n.id}
            className={`fb-nav-btn ${active === n.id ? "active" : ""}`}
            onClick={() => setActive(n.id)}
            aria-label={n.id}
          >
            {n.icon}
          </button>
        ))}
      </nav>
      <div className="fb-header-right">
        <button className="fb-icon-btn" aria-label="Menu">⋮⋮</button>
        <button className="fb-icon-btn" aria-label="Messenger">💬</button>
        <button className="fb-icon-btn" aria-label="Notifications">🔔</button>
        <div className="fb-avatar">JD</div>
      </div>
    </header>
  );
}
