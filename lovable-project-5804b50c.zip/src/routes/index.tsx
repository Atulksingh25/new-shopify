import { createFileRoute } from "@tanstack/react-router";
import AmazonApp from "@/components/amazon/AmazonApp";

export const Route = createFileRoute("/")({
  component: AmazonApp,
  head: () => ({
    meta: [
      { title: "Amazon Clone - Simple React" },
      { name: "description", content: "Amazon clone built with pure React + CSS." },
    ],
  }),
});
